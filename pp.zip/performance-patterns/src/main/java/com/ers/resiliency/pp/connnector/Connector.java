package com.ers.resiliency.pp.connnector;

import java.util.concurrent.CompletableFuture;

public interface Connector {
    String failure();

    String success();

    String ignoreException();

    String failureWithFallback();

    CompletableFuture<String> futureSuccess();

    CompletableFuture<String> futureFailure();

}
