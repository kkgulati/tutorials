package com.ers.resiliency.pp.service;


import java.util.concurrent.CompletableFuture;

public interface BusinessService {
    String failure();

    String success();

    String ignore();

    String failureWithFallback();

    CompletableFuture<String> futureSuccess();

    CompletableFuture<String> futureFailure();
}
