package com.ers.resiliency.pp.controller;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ers.resiliency.pp.service.BusinessService;

@RestController
@RequestMapping(value = "/backendC")
public class BackendCController {

    private final BusinessService businessCService;

    public BackendCController(@Qualifier("businessCService")BusinessService businessCService){
        this.businessCService = businessCService;
    }

    @GetMapping("failure")
    public String failure(){
        return businessCService.failure();
    }

    @GetMapping("success")
    public String success(){
        return businessCService.success();
    }

    @GetMapping("ignore")
    public String ignore(){
        return businessCService.ignore();
    }

    @GetMapping("futureFailure")
    public CompletableFuture<String> futureFailure(){
        return businessCService.futureFailure();
    }

    @GetMapping("futureSuccess")
    public CompletableFuture<String> futureSuccess(){
        return businessCService.futureSuccess();
    }

    @GetMapping("fallback")
    public String failureWithFallback(){
        return businessCService.failureWithFallback();
    }
}
