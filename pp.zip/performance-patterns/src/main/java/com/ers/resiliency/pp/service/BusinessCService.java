package com.ers.resiliency.pp.service;


import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ers.resiliency.pp.connnector.Connector;

@Service(value = "businessCService")
public class BusinessCService implements BusinessService  {

    private final Connector backendCConnector;

    public BusinessCService(@Qualifier("backendCConnector") Connector backendCConnector){
        this.backendCConnector = backendCConnector;
    }

    @Override
    public String failure() {
        return backendCConnector.failure();
    }

    @Override
    public String success() {
        return backendCConnector.success();
    }

    @Override
    public String ignore() {
        return backendCConnector.ignoreException();
    }
    

    @Override
    public CompletableFuture<String> futureSuccess() {
        return backendCConnector.futureSuccess();
    }

    @Override
    public CompletableFuture<String> futureFailure() {
        return backendCConnector.futureFailure();
    }

    @Override
    public String failureWithFallback() {
        return backendCConnector.failureWithFallback();
    }
}
